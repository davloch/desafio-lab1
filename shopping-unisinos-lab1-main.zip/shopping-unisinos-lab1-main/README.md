# shopping-unisinos-lab1
Código em JAVA para apresentação como trabalho final na cadeira de Laboratório 1

Contendo as classes necessárias para atender o especificado e rodar o validador da forma correta.
